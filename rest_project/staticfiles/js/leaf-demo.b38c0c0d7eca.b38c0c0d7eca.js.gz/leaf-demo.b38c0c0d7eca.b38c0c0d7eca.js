/** * Created by renato on 12/12/16. */
 /* load maps basic interface*/
var map = L.map( 'map', {
    center: [50.0, 10.0],
    minZoom: 0,
    maxZoom: 18,
    zoom: 2
});
